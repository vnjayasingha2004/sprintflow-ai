export default function HomePage() {
  return (
    <main className="min-h-screen bg-black text-white">
      <section className="mx-auto flex min-h-screen max-w-7xl flex-col justify-center px-6 py-20">
        <div className="mb-6 inline-flex w-fit items-center rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/80">
          AI-powered project planning for modern teams
        </div>

        <h1 className="max-w-4xl text-5xl font-semibold tracking-tight sm:text-6xl md:text-7xl">
          Plan faster. Build smarter. Move with
          <span className="block bg-gradient-to-r from-white to-white/50 bg-clip-text text-transparent">
            SprintFlow AI
          </span>
        </h1>

        <p className="mt-6 max-w-2xl text-lg text-white/70 sm:text-xl">
          A modern SaaS-style task planning platform that helps teams turn ideas
          into structured tasks, priorities, and sprint-ready work using AI.
        </p>

        <div className="mt-10 flex flex-wrap gap-4">
          <a
            href="/dashboard"
            className="rounded-2xl bg-white px-6 py-3 font-medium text-black transition hover:scale-[1.02]"
          >
            Open Dashboard
          </a>

          <a
            href="#features"
            className="rounded-2xl border border-white/10 bg-white/5 px-6 py-3 font-medium text-white transition hover:bg-white/10"
          >
            Explore Features
          </a>
        </div>

        <div className="mt-16 grid gap-4 md:grid-cols-3">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
            <p className="text-sm text-white/60">AI Task Planning</p>
            <h3 className="mt-2 text-xl font-semibold">
              Turn feature ideas into actionable tasks
            </h3>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
            <p className="text-sm text-white/60">Kanban Workflow</p>
            <h3 className="mt-2 text-xl font-semibold">
              Organize work across every sprint stage
            </h3>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
            <p className="text-sm text-white/60">Project Visibility</p>
            <h3 className="mt-2 text-xl font-semibold">
              Track progress, deadlines, and blockers
            </h3>
          </div>
        </div>
      </section>
    </main>
  );
}