export default function SettingsPage() {
  return (
    <div className="space-y-8">
      <div>
        <p className="text-sm text-white/50">Workspace</p>
        <h1 className="text-3xl font-semibold">Settings</h1>
        <p className="mt-2 text-white/60">
          Manage workspace preferences, notifications, and appearance.
        </p>
      </div>

      <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
        <p className="text-white/60">Settings page coming next.</p>
      </div>
    </div>
  );
}