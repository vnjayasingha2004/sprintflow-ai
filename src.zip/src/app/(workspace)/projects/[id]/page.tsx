"use client";

import { ChangeEvent, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { motion } from "framer-motion";
import {
  CalendarDays,
  CircleDashed,
  Clock3,
  FolderKanban,
  Sparkles,
  ArrowLeft,
  Trash2,
  Pencil,
  Save,
  X,
  Upload,
  FileText,
  Image as ImageIcon,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { createClient } from "@/lib/supabase/client";

type Project = {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
};

type TaskStatus = "To Do" | "In Progress" | "Review" | "Done";
type TaskPriority = "High" | "Medium" | "Low";

type Task = {
  id: string;
  project_id: string;
  title: string;
  description: string | null;
  priority: TaskPriority;
  status: TaskStatus;
  acceptance_criteria: string[] | null;
  created_at: string;
};

type TaskBreakdown = {
  summary: string;
  steps: string[];
  technicalNotes: string[];
  testingChecklist: string[];
};

type TaskAIDetailsRow = {
  id: string;
  task_id: string;
  summary: string | null;
  steps: string[] | null;
  technical_notes: string[] | null;
  testing_checklist: string[] | null;
  created_at: string;
  updated_at: string;
};

type TaskAIMessage = {
  id: string;
  task_id: string;
  role: "user" | "assistant";
  message: string;
  created_at: string;
};

type ProjectDocument = {
  id: string;
  project_id: string;
  file_name: string;
  file_path: string;
  public_url: string;
  mime_type: string | null;
  size_bytes: number | null;
  created_at: string;
};

const columnOrder: TaskStatus[] = ["To Do", "In Progress", "Review", "Done"];

const quickFollowupPrompts = [
  "Can I finish this in 2 weeks?",
  "What API endpoints do I need?",
  "Give me a simple database schema for this task.",
  "What should I test first?",
];

function getPriorityStyles(priority: TaskPriority) {
  if (priority === "High") return "bg-white text-black";
  if (priority === "Medium") return "bg-white/15 text-white";
  return "bg-white/5 text-white/70";
}

function getDocumentIcon(fileName: string) {
  const lower = fileName.toLowerCase();

  if (
    lower.endsWith(".png") ||
    lower.endsWith(".jpg") ||
    lower.endsWith(".jpeg") ||
    lower.endsWith(".webp")
  ) {
    return ImageIcon;
  }

  return FileText;
}

function mapTaskAIDetailsRowToBreakdown(row: TaskAIDetailsRow): TaskBreakdown {
  return {
    summary: row.summary || "",
    steps: row.steps || [],
    technicalNotes: row.technical_notes || [],
    testingChecklist: row.testing_checklist || [],
  };
}

export default function ProjectDetailsPage() {
  const supabase = useMemo(() => createClient(), []);
  const params = useParams<{ id: string }>();
  const projectId = Array.isArray(params?.id) ? params.id[0] : params?.id;

  const [project, setProject] = useState<Project | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [updatingTaskId, setUpdatingTaskId] = useState("");
  const [deletingTaskId, setDeletingTaskId] = useState("");

  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskDescription, setNewTaskDescription] = useState("");
  const [newTaskPriority, setNewTaskPriority] =
    useState<TaskPriority>("Medium");
  const [newTaskStatus, setNewTaskStatus] = useState<TaskStatus>("To Do");
  const [newTaskCriteria, setNewTaskCriteria] = useState("");
  const [creatingTask, setCreatingTask] = useState(false);

  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isTaskDialogOpen, setIsTaskDialogOpen] = useState(false);

  const [isEditingProject, setIsEditingProject] = useState(false);
  const [editedProjectName, setEditedProjectName] = useState("");
  const [editedProjectDescription, setEditedProjectDescription] = useState("");
  const [updatingProject, setUpdatingProject] = useState(false);

  const [taskBreakdown, setTaskBreakdown] = useState<TaskBreakdown | null>(
    null
  );
  const [loadingTaskBreakdown, setLoadingTaskBreakdown] = useState(false);
  const [taskBreakdownError, setTaskBreakdownError] = useState("");

  const [taskMessages, setTaskMessages] = useState<TaskAIMessage[]>([]);
  const [followupQuestion, setFollowupQuestion] = useState("");
  const [sendingFollowup, setSendingFollowup] = useState(false);
  const [clearingChat, setClearingChat] = useState(false);

  const [projectDocuments, setProjectDocuments] = useState<ProjectDocument[]>(
    []
  );
  const [uploadingDocument, setUploadingDocument] = useState(false);
  const [deletingDocumentId, setDeletingDocumentId] = useState("");

  useEffect(() => {
    if (!projectId) return;

    async function loadProjectDetails() {
      setLoading(true);
      setError("");

      const { data: projectData, error: projectError } = await supabase
        .from("projects")
        .select("*")
        .eq("id", projectId)
        .single();

      if (projectError) {
        setError(projectError.message);
        setLoading(false);
        return;
      }

      const { data: taskData, error: taskError } = await supabase
        .from("tasks")
        .select("*")
        .eq("project_id", projectId)
        .order("created_at", { ascending: true });

      const loadedProject = projectData as Project;

      setProject(loadedProject);
      setEditedProjectName(loadedProject.name);
      setEditedProjectDescription(loadedProject.description || "");

      if (taskError) {
        setError(taskError.message);
        setLoading(false);
        return;
      }

      setTasks((taskData ?? []) as Task[]);
      setLoading(false);
    }

    void loadProjectDetails();
  }, [projectId]);

  useEffect(() => {
    if (!projectId) return;

    async function loadProjectDocuments() {
      const { data, error } = await supabase
        .from("project_documents")
        .select("*")
        .eq("project_id", projectId)
        .order("created_at", { ascending: false });

      if (error) {
        setError(error.message);
        return;
      }

      setProjectDocuments((data ?? []) as ProjectDocument[]);
    }

    void loadProjectDocuments();
  }, [projectId]);

  useEffect(() => {
    if (!selectedTask || !isTaskDialogOpen) return;

    const taskId = selectedTask.id;

    async function loadTaskMessages() {
      setTaskMessages([]);
      setFollowupQuestion("");

      const { data, error } = await supabase
        .from("task_ai_messages")
        .select("*")
        .eq("task_id", taskId)
        .order("created_at", { ascending: true });

      if (error) {
        setTaskBreakdownError(error.message);
        return;
      }

      setTaskMessages((data ?? []) as TaskAIMessage[]);
    }

    void loadTaskMessages();
  }, [selectedTask, isTaskDialogOpen]);

  useEffect(() => {
    if (!selectedTask || !isTaskDialogOpen) return;

    const taskId = selectedTask.id;

    async function loadSavedTaskBreakdown() {
      setTaskBreakdownError("");
      setTaskBreakdown(null);

      const { data, error } = await supabase
        .from("task_ai_details")
        .select("*")
        .eq("task_id", taskId)
        .maybeSingle();

      if (error) {
        setTaskBreakdownError(error.message);
        return;
      }

      if (data) {
        setTaskBreakdown(
          mapTaskAIDetailsRowToBreakdown(data as TaskAIDetailsRow)
        );
      }
    }

    void loadSavedTaskBreakdown();
  }, [selectedTask, isTaskDialogOpen]);

  async function handleUpdateProject() {
    if (!project) return;

    if (!editedProjectName.trim()) {
      setError("Project name is required.");
      return;
    }

    setUpdatingProject(true);
    setError("");

    const { data, error } = await supabase
      .from("projects")
      .update({
        name: editedProjectName.trim(),
        description: editedProjectDescription.trim() || null,
      })
      .eq("id", project.id)
      .select()
      .single();

    if (error) {
      setError(error.message);
      setUpdatingProject(false);
      return;
    }

    const updatedProject = data as Project;

    setProject(updatedProject);
    setEditedProjectName(updatedProject.name);
    setEditedProjectDescription(updatedProject.description || "");
    setIsEditingProject(false);
    setUpdatingProject(false);
  }

  async function handleStatusChange(taskId: string, newStatus: TaskStatus) {
    setUpdatingTaskId(taskId);
    setError("");

    const previousTasks = tasks;

    const updatedTasks = tasks.map((task) =>
      task.id === taskId ? { ...task, status: newStatus } : task
    );

    setTasks(updatedTasks);

    if (selectedTask?.id === taskId) {
      setSelectedTask({ ...selectedTask, status: newStatus });
    }

    const { error } = await supabase
      .from("tasks")
      .update({ status: newStatus })
      .eq("id", taskId);

    if (error) {
      setTasks(previousTasks);
      setError(error.message);

      const previousSelectedTask = previousTasks.find(
        (task) => task.id === taskId
      );

      if (previousSelectedTask) {
        setSelectedTask(previousSelectedTask);
      }
    }

    setUpdatingTaskId("");
  }

  async function handleDeleteTask(taskId: string) {
    setDeletingTaskId(taskId);
    setError("");

    const previousTasks = tasks;
    const updatedTasks = tasks.filter((task) => task.id !== taskId);

    setTasks(updatedTasks);

    if (selectedTask?.id === taskId) {
      setSelectedTask(null);
      setIsTaskDialogOpen(false);
      setTaskBreakdown(null);
      setTaskBreakdownError("");
      setTaskMessages([]);
      setFollowupQuestion("");
    }

    const { error } = await supabase.from("tasks").delete().eq("id", taskId);

    if (error) {
      setTasks(previousTasks);
      setError(error.message);
    }

    setDeletingTaskId("");
  }

  async function handleCreateTask() {
    if (!projectId) return;

    if (!newTaskTitle.trim()) {
      setError("Task title is required.");
      return;
    }

    setCreatingTask(true);
    setError("");

    const acceptanceCriteria = newTaskCriteria
      .split("\n")
      .map((item) => item.trim())
      .filter(Boolean);

    const { data, error } = await supabase
      .from("tasks")
      .insert([
        {
          project_id: projectId,
          title: newTaskTitle.trim(),
          description: newTaskDescription.trim() || null,
          priority: newTaskPriority,
          status: newTaskStatus,
          acceptance_criteria: acceptanceCriteria,
        },
      ])
      .select()
      .single();

    if (error) {
      setError(error.message);
      setCreatingTask(false);
      return;
    }

    setTasks((prev) => [...prev, data as Task]);

    setNewTaskTitle("");
    setNewTaskDescription("");
    setNewTaskPriority("Medium");
    setNewTaskStatus("To Do");
    setNewTaskCriteria("");
    setCreatingTask(false);
  }

  async function handleProjectDocumentUpload(
    event: ChangeEvent<HTMLInputElement>
  ) {
    if (!projectId) return;

    const file = event.target.files?.[0];

    if (!file) return;

    setUploadingDocument(true);
    setError("");

    try {
      const fileExt = file.name.split(".").pop()?.toLowerCase() || "file";
      const safeBaseName = file.name
        .replace(/\.[^/.]+$/, "")
        .replace(/[^a-zA-Z0-9-_]/g, "-")
        .toLowerCase();

      const filePath = `${projectId}/${Date.now()}-${safeBaseName}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from("project-documents")
        .upload(filePath, file, {
          upsert: false,
        });

      if (uploadError) {
        throw new Error(uploadError.message);
      }

      const { data: publicUrlData } = supabase.storage
        .from("project-documents")
        .getPublicUrl(filePath);

      const publicUrl = publicUrlData.publicUrl;

      const { data: insertedRow, error: insertError } = await supabase
        .from("project_documents")
        .insert([
          {
            project_id: projectId,
            file_name: file.name,
            file_path: filePath,
            public_url: publicUrl,
            mime_type: file.type || null,
            size_bytes: file.size,
          },
        ])
        .select()
        .single();

      if (insertError) {
        throw new Error(insertError.message);
      }

      setProjectDocuments((prev) => [insertedRow as ProjectDocument, ...prev]);
      event.target.value = "";
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong while uploading the document."
      );
    } finally {
      setUploadingDocument(false);
    }
  }

  async function handleDeleteProjectDocument(document: ProjectDocument) {
    setDeletingDocumentId(document.id);
    setError("");

    try {
      const { error: storageError } = await supabase.storage
        .from("project-documents")
        .remove([document.file_path]);

      if (storageError) {
        throw new Error(storageError.message);
      }

      const { error: deleteRowError } = await supabase
        .from("project_documents")
        .delete()
        .eq("id", document.id);

      if (deleteRowError) {
        throw new Error(deleteRowError.message);
      }

      setProjectDocuments((prev) =>
        prev.filter((item) => item.id !== document.id)
      );
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong while deleting the document."
      );
    } finally {
      setDeletingDocumentId("");
    }
  }

  function handleOpenTask(task: Task) {
    setSelectedTask(task);
    setIsTaskDialogOpen(true);
    setTaskBreakdown(null);
    setTaskBreakdownError("");
    setTaskMessages([]);
    setFollowupQuestion("");
  }

  async function handleGenerateTaskBreakdown() {
    if (!selectedTask || !project) return;

    const safeTitle =
      selectedTask.title?.trim() ||
      selectedTask.description?.trim()?.slice(0, 80) ||
      "Untitled Task";

    setLoadingTaskBreakdown(true);
    setTaskBreakdownError("");
    setTaskBreakdown(null);

    try {
      const response = await fetch("/api/ai/task-details", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          projectName: project.name,
          title: safeTitle,
          description: selectedTask.description,
          acceptanceCriteria: selectedTask.acceptance_criteria ?? [],
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to generate task breakdown.");
      }

      if (!data.breakdown) {
        throw new Error("No breakdown was returned from the server.");
      }

      const breakdown = data.breakdown as TaskBreakdown;
      setTaskBreakdown(breakdown);

      const { error: saveError } = await supabase
        .from("task_ai_details")
        .upsert(
          [
            {
              task_id: selectedTask.id,
              summary: breakdown.summary,
              steps: breakdown.steps,
              technical_notes: breakdown.technicalNotes,
              testing_checklist: breakdown.testingChecklist,
            },
          ],
          {
            onConflict: "task_id",
          }
        );

      if (saveError) {
        throw new Error(saveError.message);
      }
    } catch (err) {
      setTaskBreakdownError(
        err instanceof Error
          ? err.message
          : "Something went wrong while generating task breakdown."
      );
    } finally {
      setLoadingTaskBreakdown(false);
    }
  }

  async function handleSendFollowup() {
    if (!selectedTask || !project) return;

    const taskId = selectedTask.id;
    const trimmedQuestion = followupQuestion.trim();

    if (!trimmedQuestion) return;

    setSendingFollowup(true);
    setTaskBreakdownError("");
    setFollowupQuestion("");

    try {
      const { error: userSaveError } = await supabase
        .from("task_ai_messages")
        .insert([
          {
            task_id: taskId,
            role: "user",
            message: trimmedQuestion,
          },
        ]);

      if (userSaveError) {
        throw new Error(userSaveError.message);
      }

      const { data: latestMessages, error: latestMessagesError } =
        await supabase
          .from("task_ai_messages")
          .select("*")
          .eq("task_id", taskId)
          .order("created_at", { ascending: true });

      if (latestMessagesError) {
        throw new Error(latestMessagesError.message);
      }

      setTaskMessages((latestMessages ?? []) as TaskAIMessage[]);

      const response = await fetch("/api/ai/task-followup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          projectName: project.name,
          taskTitle: selectedTask.title,
          taskDescription: selectedTask.description,
          acceptanceCriteria: selectedTask.acceptance_criteria ?? [],
          breakdownSummary: taskBreakdown?.summary ?? "",
          question: trimmedQuestion,
          history: (latestMessages ?? []).map((item) => ({
            role: item.role,
            message: item.message,
          })),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to get AI follow-up answer.");
      }

      const answer = data.answer as string;

      const { error: assistantSaveError } = await supabase
        .from("task_ai_messages")
        .insert([
          {
            task_id: taskId,
            role: "assistant",
            message: answer,
          },
        ]);

      if (assistantSaveError) {
        throw new Error(assistantSaveError.message);
      }

      const { data: refreshedMessages, error: refreshError } = await supabase
        .from("task_ai_messages")
        .select("*")
        .eq("task_id", taskId)
        .order("created_at", { ascending: true });

      if (refreshError) {
        throw new Error(refreshError.message);
      }

      setTaskMessages((refreshedMessages ?? []) as TaskAIMessage[]);
    } catch (err) {
      setTaskBreakdownError(
        err instanceof Error
          ? err.message
          : "Something went wrong while sending the follow-up question."
      );
    } finally {
      setSendingFollowup(false);
    }
  }

  async function handleClearTaskChat() {
    if (!selectedTask) return;

    setClearingChat(true);
    setTaskBreakdownError("");

    try {
      const { error } = await supabase
        .from("task_ai_messages")
        .delete()
        .eq("task_id", selectedTask.id);

      if (error) {
        throw new Error(error.message);
      }

      setTaskMessages([]);
      setFollowupQuestion("");
    } catch (err) {
      setTaskBreakdownError(
        err instanceof Error
          ? err.message
          : "Something went wrong while clearing the chat."
      );
    } finally {
      setClearingChat(false);
    }
  }

  const columns = useMemo(() => {
    return columnOrder.map((status) => ({
      id: status,
      title: status,
      tasks: tasks.filter((task) => task.status === status),
    }));
  }, [tasks]);

  const progress = tasks.length
    ? Math.round(
        (tasks.filter((task) => task.status === "Done").length / tasks.length) *
          100
      )
    : 0;

  if (loading) {
    return (
      <div className="space-y-8">
        <div className="rounded-[28px] border border-white/10 bg-white/5 p-6 md:p-8">
          <p className="text-white/60">Loading project...</p>
        </div>
      </div>
    );
  }

  if (error && !project) {
    return (
      <div className="space-y-8">
        <div className="rounded-[28px] border border-red-500/20 bg-red-500/10 p-6 md:p-8">
          <p className="text-red-200">{error}</p>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="space-y-8">
        <div className="rounded-[28px] border border-white/10 bg-white/5 p-6 md:p-8">
          <p className="text-white/60">Project not found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <motion.section
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="rounded-[28px] border border-white/10 bg-white/5 p-6 md:p-8"
      >
        <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
          <div className="max-w-3xl">
            <div className="mb-4 flex flex-wrap items-center gap-3">
              <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-sm text-white/60">
                <FolderKanban className="h-4 w-4" />
                Project Details
              </div>

              <Link
                href="/projects"
                className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-sm text-white/60 transition hover:bg-white/10 hover:text-white"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Projects
              </Link>
            </div>

            <p className="mb-3 text-sm text-white/45">Project ID: {project.id}</p>

            {isEditingProject ? (
              <div className="space-y-4">
                <div>
                  <label className="mb-2 block text-sm text-white/70">
                    Project name
                  </label>
                  <input
                    value={editedProjectName}
                    onChange={(e) => setEditedProjectName(e.target.value)}
                    className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white outline-none placeholder:text-white/30"
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm text-white/70">
                    Description
                  </label>
                  <textarea
                    value={editedProjectDescription}
                    onChange={(e) => setEditedProjectDescription(e.target.value)}
                    placeholder="Project description..."
                    className="min-h-[120px] w-full resize-none rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white outline-none placeholder:text-white/30"
                  />
                </div>

                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={handleUpdateProject}
                    disabled={updatingProject}
                    className="inline-flex items-center gap-2 rounded-2xl bg-white px-4 py-2 font-medium text-black transition hover:scale-[1.02] disabled:opacity-60"
                  >
                    <Save className="h-4 w-4" />
                    {updatingProject ? "Saving..." : "Save Changes"}
                  </button>

                  <button
                    onClick={() => {
                      setIsEditingProject(false);
                      setEditedProjectName(project.name);
                      setEditedProjectDescription(project.description || "");
                    }}
                    className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-2 font-medium text-white transition hover:bg-white/10"
                  >
                    <X className="h-4 w-4" />
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex flex-wrap items-start gap-3">
                  <h1 className="text-3xl font-semibold md:text-4xl">
                    {project.name}
                  </h1>

                  <button
                    onClick={() => setIsEditingProject(true)}
                    className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-sm font-medium text-white transition hover:bg-white/10"
                  >
                    <Pencil className="h-4 w-4" />
                    Edit
                  </button>
                </div>

                <p className="mt-4 max-w-2xl text-sm leading-6 text-white/60 md:text-base">
                  {project.description || "No description provided yet."}
                </p>
              </>
            )}

            <div className="mt-6 flex flex-wrap gap-3">
              <div className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-black/30 px-4 py-2 text-sm text-white/70">
                <CircleDashed className="h-4 w-4" />
                {tasks.length === 0 ? "No Tasks Yet" : "Active Project"}
              </div>

              <div className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-black/30 px-4 py-2 text-sm text-white/70">
                <CalendarDays className="h-4 w-4" />
                Created {new Date(project.created_at).toLocaleDateString()}
              </div>

              <div className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-black/30 px-4 py-2 text-sm text-white/70">
                <Clock3 className="h-4 w-4" />
                {progress}% complete
              </div>
            </div>

            {error && (
              <div className="mt-4 rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
                {error}
              </div>
            )}
          </div>

          <div className="w-full max-w-sm rounded-3xl border border-white/10 bg-black/30 p-5">
            <div className="flex items-center justify-between">
              <p className="text-sm text-white/50">AI Assistant</p>
              <Sparkles className="h-4 w-4 text-white/70" />
            </div>

            <h3 className="mt-3 text-lg font-semibold">
              Generate sprint tasks for this project
            </h3>

            <p className="mt-2 text-sm leading-6 text-white/60">
              Open the AI Planner, generate tasks, and save them to this project
              board.
            </p>

            <Link
              href="/ai-planner"
              className="mt-5 inline-flex rounded-2xl bg-white px-4 py-2 font-medium text-black transition hover:scale-[1.02]"
            >
              Open AI Planner
            </Link>
          </div>
        </div>
      </motion.section>

      <section className="rounded-[28px] border border-white/10 bg-white/5 p-6 md:p-8">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm text-white/50">Project Source Documents</p>
            <h2 className="text-2xl font-semibold text-white">Attached files</h2>
            <p className="mt-2 text-sm text-white/60">
              Upload requirement docs, PDFs, or images and link them to this
              project.
            </p>
          </div>

          <label className="inline-flex cursor-pointer items-center gap-2 rounded-2xl bg-white px-4 py-2.5 font-medium text-black transition hover:scale-[1.02]">
            <Upload className="h-4 w-4" />
            {uploadingDocument ? "Uploading..." : "Upload Document"}
            <input
              type="file"
              accept=".pdf,.docx,.png,.jpg,.jpeg,.webp"
              className="hidden"
              onChange={handleProjectDocumentUpload}
              disabled={uploadingDocument}
            />
          </label>
        </div>

        <div className="mt-6 space-y-3">
          {projectDocuments.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-white/10 bg-black/20 p-4 text-sm text-white/40">
              No documents attached yet.
            </div>
          ) : (
            projectDocuments.map((document) => {
              const DocIcon = getDocumentIcon(document.file_name);

              return (
                <div
                  key={document.id}
                  className="flex flex-col gap-4 rounded-3xl border border-white/10 bg-black/30 p-4 md:flex-row md:items-center md:justify-between"
                >
                  <div className="flex items-start gap-3">
                    <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
                      <DocIcon className="h-5 w-5 text-white/80" />
                    </div>

                    <div>
                      <p className="font-medium text-white">
                        {document.file_name}
                      </p>
                      <p className="mt-1 text-sm text-white/45">
                        {document.size_bytes
                          ? `${(document.size_bytes / 1024 / 1024).toFixed(2)} MB`
                          : "Unknown size"}{" "}
                        • {new Date(document.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    <Link
                      href={`/ai-planner?projectId=${project.id}&documentId=${document.id}`}
                      className="inline-flex items-center gap-2 rounded-2xl bg-white px-4 py-2 text-sm font-medium text-black transition hover:scale-[1.02]"
                    >
                      Generate Tasks
                    </Link>

                    <a
                      href={document.public_url}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/10"
                    >
                      Open File
                    </a>

                    <button
                      onClick={() => handleDeleteProjectDocument(document)}
                      disabled={deletingDocumentId === document.id}
                      className="inline-flex items-center gap-2 rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-2 text-sm font-medium text-red-200 transition hover:bg-red-500/20 disabled:opacity-60"
                    >
                      <Trash2 className="h-4 w-4" />
                      {deletingDocumentId === document.id
                        ? "Deleting..."
                        : "Delete"}
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </section>

      <section className="rounded-[28px] border border-white/10 bg-white/5 p-6 md:p-8">
        <div className="mb-4">
          <p className="text-sm text-white/50">Manual Task Creation</p>
          <h2 className="text-2xl font-semibold text-white">Add a task</h2>
          <p className="mt-2 text-sm text-white/60">
            Create your own task manually and add it directly to this project
            board.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <div className="md:col-span-2">
            <label className="mb-2 block text-sm text-white/70">
              Task title
            </label>
            <input
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              placeholder="Example: Implement lawyer profile page"
              className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white outline-none placeholder:text-white/30"
            />
          </div>

          <div className="md:col-span-2">
            <label className="mb-2 block text-sm text-white/70">
              Description
            </label>
            <textarea
              value={newTaskDescription}
              onChange={(e) => setNewTaskDescription(e.target.value)}
              placeholder="Short explanation of the task..."
              className="min-h-[120px] w-full resize-none rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white outline-none placeholder:text-white/30"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm text-white/70">Priority</label>
            <select
              value={newTaskPriority}
              onChange={(e) =>
                setNewTaskPriority(e.target.value as TaskPriority)
              }
              className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white outline-none"
            >
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>

          <div>
            <label className="mb-2 block text-sm text-white/70">Status</label>
            <select
              value={newTaskStatus}
              onChange={(e) => setNewTaskStatus(e.target.value as TaskStatus)}
              className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white outline-none"
            >
              <option value="To Do">To Do</option>
              <option value="In Progress">In Progress</option>
              <option value="Review">Review</option>
              <option value="Done">Done</option>
            </select>
          </div>

          <div className="md:col-span-2">
            <label className="mb-2 block text-sm text-white/70">
              Acceptance criteria
            </label>
            <textarea
              value={newTaskCriteria}
              onChange={(e) => setNewTaskCriteria(e.target.value)}
              placeholder={`Write one criterion per line\nExample:\nUser can open the profile page\nProfile data loads from API\nValidation errors are shown correctly`}
              className="min-h-[140px] w-full resize-none rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white outline-none placeholder:text-white/30"
            />
          </div>
        </div>

        <div className="mt-5">
          <button
            onClick={handleCreateTask}
            disabled={creatingTask}
            className="inline-flex items-center gap-2 rounded-2xl bg-white px-5 py-3 font-medium text-black transition hover:scale-[1.02] disabled:opacity-60"
          >
            {creatingTask ? "Creating..." : "Create Task"}
          </button>
        </div>
      </section>

      <section>
        <div className="mb-5">
          <p className="text-sm text-white/50">Task Workflow</p>
          <h2 className="text-2xl font-semibold">Kanban Board</h2>
        </div>

        <div className="grid gap-5 xl:grid-cols-4">
          {columns.map((column, columnIndex) => (
            <motion.div
              key={column.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: columnIndex * 0.08 }}
              className="rounded-[26px] border border-white/10 bg-white/5 p-4"
            >
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-medium text-white">{column.title}</h3>
                <span className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-white/60">
                  {column.tasks.length}
                </span>
              </div>

              <div className="space-y-3">
                {column.tasks.length === 0 ? (
                  <div className="rounded-3xl border border-dashed border-white/10 bg-black/20 p-4 text-sm text-white/40">
                    No tasks in {column.title}.
                  </div>
                ) : (
                  column.tasks.map((task, taskIndex) => (
                    <motion.div
                      key={task.id}
                      initial={{ opacity: 0, scale: 0.96 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{
                        duration: 0.25,
                        delay: columnIndex * 0.08 + taskIndex * 0.04,
                      }}
                      whileHover={{ y: -4 }}
                      onClick={() => handleOpenTask(task)}
                      className="w-full cursor-pointer rounded-3xl border border-white/10 bg-black/30 p-4 text-left transition hover:bg-white/[0.06]"
                    >
                      <h4 className="text-sm font-medium text-white">
                        {task.title}
                      </h4>

                      <p className="mt-2 text-xs leading-5 text-white/50">
                        {task.description || "No description provided."}
                      </p>

                      <div className="mt-4 flex items-center justify-between gap-3">
                        <span
                          className={`rounded-full px-3 py-1 text-xs font-medium ${getPriorityStyles(
                            task.priority
                          )}`}
                        >
                          {task.priority}
                        </span>

                        <span className="text-xs text-white/40">
                          {task.acceptance_criteria?.length ?? 0} criteria
                        </span>
                      </div>

                      <div className="mt-4">
                        <label className="mb-2 block text-xs text-white/50">
                          Move task
                        </label>

                        <select
                          value={task.status}
                          onClick={(e) => e.stopPropagation()}
                          onChange={(e) =>
                            handleStatusChange(
                              task.id,
                              e.target.value as TaskStatus
                            )
                          }
                          disabled={updatingTaskId === task.id}
                          className="w-full rounded-2xl border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none"
                        >
                          <option value="To Do">To Do</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Review">Review</option>
                          <option value="Done">Done</option>
                        </select>
                      </div>

                      <div className="mt-3">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteTask(task.id);
                          }}
                          disabled={deletingTaskId === task.id}
                          className="inline-flex items-center gap-2 rounded-2xl border border-red-500/20 bg-red-500/10 px-3 py-2 text-xs font-medium text-red-200 transition hover:bg-red-500/20 disabled:opacity-60"
                        >
                          <Trash2 className="h-4 w-4" />
                          {deletingTaskId === task.id
                            ? "Deleting..."
                            : "Delete Task"}
                        </button>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <Dialog
        open={isTaskDialogOpen}
        onOpenChange={(open) => {
          setIsTaskDialogOpen(open);
          if (!open) {
            setSelectedTask(null);
            setTaskBreakdown(null);
            setTaskBreakdownError("");
            setTaskMessages([]);
            setFollowupQuestion("");
          }
        }}
      >
        <DialogContent className="border-white/10 bg-zinc-950 p-0 text-white sm:max-w-4xl max-h-[90vh] overflow-hidden">
          <DialogHeader className="sticky top-0 z-10 border-b border-white/10 bg-zinc-950 px-6 py-5">
            <DialogTitle className="text-2xl font-semibold text-white">
              {selectedTask?.title}
            </DialogTitle>
            <DialogDescription className="text-white/50">
              Detailed task view
            </DialogDescription>
          </DialogHeader>

          {selectedTask && (
            <div className="max-h-[75vh] space-y-6 overflow-y-auto px-6 py-5 pr-4">
              <div className="flex flex-wrap items-center gap-3">
                <span
                  className={`rounded-full px-3 py-1 text-xs font-medium ${getPriorityStyles(
                    selectedTask.priority
                  )}`}
                >
                  {selectedTask.priority}
                </span>

                <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/70">
                  {selectedTask.status}
                </span>
              </div>

              <div>
                <h3 className="mb-2 text-sm font-medium text-white/70">
                  Description
                </h3>
                <div className="rounded-3xl border border-white/10 bg-black/30 p-5 text-sm leading-6 text-white/70">
                  {selectedTask.description || "No description provided."}
                </div>
              </div>

              <div>
                <h3 className="mb-2 text-sm font-medium text-white/70">
                  Acceptance Criteria
                </h3>

                {selectedTask.acceptance_criteria &&
                selectedTask.acceptance_criteria.length > 0 ? (
                  <div className="rounded-3xl border border-white/10 bg-black/30 p-5">
                    <ul className="space-y-3">
                      {selectedTask.acceptance_criteria.map((item, index) => (
                        <li
                          key={`${selectedTask.id}-criteria-${index}`}
                          className="flex items-start gap-3 text-sm text-white/70"
                        >
                          <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-white/60" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : (
                  <div className="rounded-3xl border border-white/10 bg-black/30 p-5 text-sm text-white/50">
                    No acceptance criteria available.
                  </div>
                )}
              </div>

              <div>
                <div className="mb-4 flex flex-wrap items-center gap-3">
                  <h3 className="text-sm font-medium text-white/70">
                    AI Detailed Breakdown
                  </h3>

                  <button
                    onClick={handleGenerateTaskBreakdown}
                    disabled={loadingTaskBreakdown}
                    className="inline-flex items-center gap-2 rounded-2xl bg-white px-4 py-2.5 text-sm font-medium text-black transition hover:scale-[1.02] disabled:opacity-60"
                  >
                    {loadingTaskBreakdown
                      ? "Generating..."
                      : "Generate Breakdown"}
                  </button>
                </div>

                <p className="mb-4 text-xs text-white/40">
                  Generated breakdowns are saved for this task.
                </p>

                {taskBreakdownError && (
                  <div className="mb-4 rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
                    {taskBreakdownError}
                  </div>
                )}

                {taskBreakdown && (
                  <div className="space-y-5">
                    <div className="rounded-3xl border border-white/10 bg-black/30 p-5">
                      <h4 className="mb-2 text-sm font-medium text-white/70">
                        Summary
                      </h4>
                      <p className="text-sm leading-6 text-white/70">
                        {taskBreakdown.summary}
                      </p>
                    </div>

                    <div className="rounded-3xl border border-white/10 bg-black/30 p-5">
                      <h4 className="mb-3 text-sm font-medium text-white/70">
                        Implementation Steps
                      </h4>
                      <ul className="space-y-3">
                        {taskBreakdown.steps.map((item, index) => (
                          <li
                            key={`step-${index}`}
                            className="flex items-start gap-3 text-sm text-white/70"
                          >
                            <span className="mt-0.5 inline-flex h-5 w-5 items-center justify-center rounded-full bg-white text-[10px] font-semibold text-black">
                              {index + 1}
                            </span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="rounded-3xl border border-white/10 bg-black/30 p-5">
                      <h4 className="mb-3 text-sm font-medium text-white/70">
                        Technical Notes
                      </h4>
                      <ul className="space-y-3">
                        {taskBreakdown.technicalNotes.map((item, index) => (
                          <li
                            key={`note-${index}`}
                            className="flex items-start gap-3 text-sm text-white/70"
                          >
                            <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-white/60" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="rounded-3xl border border-white/10 bg-black/30 p-5">
                      <h4 className="mb-3 text-sm font-medium text-white/70">
                        Testing Checklist
                      </h4>
                      <ul className="space-y-3">
                        {taskBreakdown.testingChecklist.map((item, index) => (
                          <li
                            key={`test-${index}`}
                            className="flex items-start gap-3 text-sm text-white/70"
                          >
                            <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-white/60" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
                  <h3 className="text-sm font-medium text-white/70">
                    Ask AI about this task
                  </h3>

                  <button
                    onClick={handleClearTaskChat}
                    disabled={clearingChat || taskMessages.length === 0}
                    className="inline-flex items-center gap-2 rounded-2xl border border-red-500/20 bg-red-500/10 px-3 py-2 text-xs font-medium text-red-200 transition hover:bg-red-500/20 disabled:opacity-60"
                  >
                    {clearingChat ? "Clearing..." : "Clear Chat"}
                  </button>
                </div>

                <div className="rounded-3xl border border-white/10 bg-black/30 p-5">
                  {taskBreakdownError && (
                    <div className="mb-4 rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
                      {taskBreakdownError}
                    </div>
                  )}

                  {taskMessages.length === 0 ? (
                    <p className="text-sm text-white/50">
                      No follow-up questions yet. Ask something specific about
                      this task.
                    </p>
                  ) : (
                    <div className="space-y-4">
                      {taskMessages.map((message) => (
                        <div
                          key={message.id}
                          className={`rounded-2xl px-4 py-3 text-sm leading-6 ${
                            message.role === "user"
                              ? "bg-white text-black"
                              : "border border-white/10 bg-zinc-900 text-white/80"
                          }`}
                        >
                          <p className="mb-1 text-xs font-medium opacity-70">
                            {message.role === "user" ? "You" : "SprintFlow AI"}
                          </p>
                          <p className="whitespace-pre-wrap">
                            {message.message}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="mt-5">
                    <p className="mb-3 text-xs font-medium uppercase tracking-wide text-white/40">
                      Quick prompts
                    </p>

                    <div className="mb-4 flex flex-wrap gap-2">
                      {quickFollowupPrompts.map((prompt) => (
                        <button
                          key={prompt}
                          onClick={() => setFollowupQuestion(prompt)}
                          className="rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs text-white/70 transition hover:bg-white/10 hover:text-white"
                        >
                          {prompt}
                        </button>
                      ))}
                    </div>

                    <div className="space-y-3">
                      <textarea
                        value={followupQuestion}
                        onChange={(e) => setFollowupQuestion(e.target.value)}
                        placeholder="Ask a follow-up question about this task..."
                        className="min-h-[110px] w-full resize-none rounded-2xl border border-white/10 bg-zinc-950 px-4 py-3 text-white outline-none placeholder:text-white/30"
                      />

                      <button
                        onClick={handleSendFollowup}
                        disabled={sendingFollowup || !followupQuestion.trim()}
                        className="inline-flex items-center gap-2 rounded-2xl bg-white px-4 py-2.5 text-sm font-medium text-black transition hover:scale-[1.02] disabled:opacity-60"
                      >
                        {sendingFollowup ? "Sending..." : "Ask AI"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}