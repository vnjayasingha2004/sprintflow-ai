"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { ArrowUpRight, FolderKanban, Plus, Sparkles } from "lucide-react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

type Project = {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
};

export default function ProjectsPage() {
  const supabase = useMemo(() => createClient(), []);

  const [projects, setProjects] = useState<Project[]>([]);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();

  async function fetchProjects() {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    router.push("/sign-in");
    return;
  }

  const { data, error } = await supabase
    .from("projects")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Fetch projects error:", error);
    setProjects([]);
  } else {
    setProjects(data || []);
  }

  setLoading(false);
} 

  async function handleCreateProject() {
  if (!name.trim()) return;

  setSaving(true);

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    setSaving(false);
    router.push("/sign-in");
    return;
  }

  const { error } = await supabase
    .from("projects")
    .insert([
      {
        name: name.trim(),
        description: description.trim() || null,
        user_id: user.id,
      },
    ]);

  if (error) {
    console.error("Create project error:", error);
    setSaving(false);
    return;
  }

  setName("");
  setDescription("");
  setSaving(false);

  await fetchProjects();
}
  return (
    <div className="space-y-8">
      <div>
        <p className="text-sm text-white/50">Workspace</p>
        <h1 className="text-3xl font-semibold">Projects</h1>
        <p className="mt-2 max-w-2xl text-white/60">
          Create projects, organize work, and connect AI-generated tasks to real
          project boards.
        </p>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_1.4fr]">
        <div className="rounded-[28px] border border-white/10 bg-white/5 p-6">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-sm text-white/60">
            <Plus className="h-4 w-4" />
            New Project
          </div>

          <h2 className="text-2xl font-semibold text-white">Create a project</h2>
          <p className="mt-2 text-sm leading-6 text-white/60">
            Start a new workspace project and later attach AI-generated tasks to
            it.
          </p>

          <div className="mt-6 space-y-4">
            <div>
              <label className="mb-2 block text-sm text-white/70">
                Project name
              </label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Example: Admin Dashboard Revamp"
                className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white outline-none placeholder:text-white/30"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm text-white/70">
                Description
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Short project description..."
                className="min-h-[140px] w-full resize-none rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white outline-none placeholder:text-white/30"
              />
            </div>

            <button
              onClick={handleCreateProject}
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-2xl bg-white px-5 py-3 font-medium text-black transition hover:scale-[1.02] disabled:opacity-60"
            >
              <Plus className="h-4 w-4" />
              {saving ? "Creating..." : "Create Project"}
            </button>

            {error && (
              <div className="rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
                {error}
              </div>
            )}
          </div>
        </div>

        <div>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-2xl font-semibold text-white">Saved Projects</h2>
            <span className="text-sm text-white/50">
              {loading ? "Loading..." : `${projects.length} project(s)`}
            </span>
          </div>

          {loading ? (
            <div className="rounded-[28px] border border-white/10 bg-white/5 p-6 text-white/60">
              Loading projects...
            </div>
          ) : projects.length === 0 ? (
            <div className="rounded-[28px] border border-dashed border-white/15 bg-white/5 p-8 text-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-3xl border border-white/10 bg-white/5">
                <FolderKanban className="h-6 w-6 text-white/70" />
              </div>

              <h3 className="mt-5 text-xl font-semibold text-white">
                No projects yet
              </h3>

              <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-white/60">
                Create your first project to start organizing tasks and
                AI-generated work.
              </p>
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2">
              {projects.map((project, index) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35, delay: index * 0.08 }}
                  whileHover={{ y: -6 }}
                  className="rounded-3xl border border-white/10 bg-white/5 p-6 transition hover:bg-white/[0.07]"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/10 bg-white/5">
                      <FolderKanban className="h-5 w-5 text-white/80" />
                    </div>

                    <div className="flex h-10 w-10 items-center justify-center rounded-2xl border border-white/10 bg-white/5">
                      <Sparkles className="h-4 w-4 text-white/70" />
                    </div>
                  </div>

                  <h3 className="mt-5 text-xl font-semibold text-white">
                    {project.name}
                  </h3>

                  <p className="mt-3 text-sm leading-6 text-white/60">
                    {project.description || "No description provided yet."}
                  </p>

                  <p className="mt-4 text-xs text-white/40">
                    Created: {new Date(project.created_at).toLocaleDateString()}
                  </p>

                  <div className="mt-6">
                    <Link
                      href={`/projects/${project.id}`}
                      className="inline-flex items-center gap-2 rounded-2xl bg-white px-4 py-2 font-medium text-black transition hover:scale-[1.02]"
                    >
                      Open Project
                      <ArrowUpRight className="h-4 w-4" />
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}