"use client";

import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, CheckCircle2, Clock3, FolderKanban } from "lucide-react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

type Project = {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
};

type Task = {
  id: string;
  project_id: string;
  title: string;
  description: string | null;
  priority: "High" | "Medium" | "Low";
  status: "To Do" | "In Progress" | "Review" | "Done";
  acceptance_criteria: string[] | null;
  created_at: string;
};

export default function DashboardPage() {
  
  const [projects, setProjects] = useState<Project[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
   const supabase = createClient();


  useEffect(() => {
    async function loadDashboardData() {
      setLoading(true);
      setError("");

      const { data: projectData, error: projectError } = await supabase
        .from("projects")
        .select("*")
        .order("created_at", { ascending: false });

      if (projectError) {
        setError(projectError.message);
        setLoading(false);
        return;
      }

      const { data: taskData, error: taskError } = await supabase
        .from("tasks")
        .select("*")
        .order("created_at", { ascending: false });

      if (taskError) {
        setError(taskError.message);
        setLoading(false);
        return;
      }

      setProjects((projectData ?? []) as Project[]);
      setTasks((taskData ?? []) as Task[]);
      setLoading(false);
    }

    void loadDashboardData();
  }, []);

  const stats = useMemo(() => {
    const totalProjects = projects.length;
    const totalTasks = tasks.length;
    const inProgressTasks = tasks.filter(
      (task) => task.status === "In Progress"
    ).length;
    const completedTasks = tasks.filter(
      (task) => task.status === "Done"
    ).length;

    return [
      {
        title: "Total Projects",
        value: totalProjects.toString(),
        subtext: "Saved in workspace",
        icon: FolderKanban,
      },
      {
        title: "Total Tasks",
        value: totalTasks.toString(),
        subtext: "Across all projects",
        icon: CheckCircle2,
      },
      {
        title: "In Progress",
        value: inProgressTasks.toString(),
        subtext: "Active work items",
        icon: Clock3,
      },
      {
        title: "Completed",
        value: completedTasks.toString(),
        subtext: "Finished tasks",
        icon: ArrowUpRight,
      },
    ];
  }, [projects, tasks]);

  const recentProjects = projects.slice(0, 4);

  if (loading) {
    return (
      <div className="space-y-8">
        <div className="rounded-[28px] border border-white/10 bg-white/5 p-6 text-white/60">
          Loading dashboard...
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-8">
        <div className="rounded-[28px] border border-red-500/20 bg-red-500/10 p-6 text-red-200">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon;

          return (
            <Card
              key={stat.title}
              className="border-white/10 bg-white/5 text-white transition duration-300 hover:-translate-y-1 hover:bg-white/[0.07]"
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0">
                <CardTitle className="text-sm font-medium text-white/60">
                  {stat.title}
                </CardTitle>
                <div className="rounded-xl border border-white/10 bg-white/5 p-2">
                  <Icon className="h-4 w-4 text-white/80" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-semibold">{stat.value}</div>
                <p className="mt-2 text-sm text-white/50">{stat.subtext}</p>
              </CardContent>
            </Card>
          );
        })}
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.6fr_1fr]">
        <Card className="border-white/10 bg-white/5 text-white">
          <CardHeader>
            <CardTitle className="text-lg">Recent Projects</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentProjects.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-white/10 bg-black/20 p-4 text-sm text-white/50">
                No projects yet.
              </div>
            ) : (
              recentProjects.map((project) => {
                const projectTaskCount = tasks.filter(
                  (task) => task.project_id === project.id
                ).length;

                return (
                  <div
                    key={project.id}
                    className="flex items-center justify-between rounded-2xl border border-white/10 bg-black/30 p-4 transition hover:bg-white/5"
                  >
                    <div>
                      <h3 className="font-medium text-white">{project.name}</h3>
                      <p className="mt-1 text-sm text-white/50">
                        {projectTaskCount} task(s)
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <Badge
                        variant="secondary"
                        className="border border-white/10 bg-white/10 text-white"
                      >
                        {new Date(project.created_at).toLocaleDateString()}
                      </Badge>

                      <Link
                        href={`/projects/${project.id}`}
                        className="rounded-xl bg-white px-3 py-2 text-sm font-medium text-black transition hover:scale-[1.02]"
                      >
                        Open
                      </Link>
                    </div>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>

        <Card className="border-white/10 bg-white/5 text-white">
          <CardHeader>
            <CardTitle className="text-lg">Workspace Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 rounded-3xl border border-white/10 bg-black/30 p-5">
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/50">Projects</span>
                <span className="font-medium text-white">{projects.length}</span>
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-white/50">Tasks</span>
                <span className="font-medium text-white">{tasks.length}</span>
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-white/50">To Do</span>
                <span className="font-medium text-white">
                  {tasks.filter((task) => task.status === "To Do").length}
                </span>
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-white/50">Review</span>
                <span className="font-medium text-white">
                  {tasks.filter((task) => task.status === "Review").length}
                </span>
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-white/50">Done</span>
                <span className="font-medium text-white">
                  {tasks.filter((task) => task.status === "Done").length}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}