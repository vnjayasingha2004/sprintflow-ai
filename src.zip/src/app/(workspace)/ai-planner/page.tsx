"use client";

import { ChangeEvent, useEffect, useMemo, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { createClient } from "@/lib/supabase/client";
import {
  Sparkles,
  LoaderCircle,
  WandSparkles,
  CheckCircle2,
  Flag,
  ListTodo,
  Paperclip,
  FileText,
  Image as ImageIcon,
  Upload,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";

type GeneratedTask = {
  id: number;
  title: string;
  description: string;
  priority: "High" | "Medium" | "Low";
  status: "To Do" | "In Progress" | "Review";
  acceptanceCriteria: string[];
};

type ProjectOption = {
  id: string;
  name: string;
};

type SavedProjectDocument = {
  id: string;
  project_id: string;
  file_name: string;
  public_url: string;
  mime_type: string | null;
  size_bytes: number | null;
};

const examplePrompts = [
  "Build a fitness app dashboard with login, profile editing, and weekly progress charts.",
  "Create an e-commerce admin panel with product management, order tracking, and coupon support.",
  "Design a team chat feature with channels, notifications, file sharing, and unread message counts.",
];

const supportedFileTypes = [
  ".pdf",
  ".docx",
  ".png",
  ".jpg",
  ".jpeg",
  ".webp",
];

function getPriorityStyles(priority: GeneratedTask["priority"]) {
  if (priority === "High") return "bg-white text-black";
  if (priority === "Medium") return "bg-white/15 text-white";
  return "bg-white/5 text-white/70";
}

function normalizeTasks(
  tasks: Omit<GeneratedTask, "id">[] | GeneratedTask[]
): GeneratedTask[] {
  return tasks.map((task, index) => ({
    ...task,
    id: index + 1,
  }));
}

function getFileIcon(fileName: string) {
  const lower = fileName.toLowerCase();

  if (
    lower.endsWith(".png") ||
    lower.endsWith(".jpg") ||
    lower.endsWith(".jpeg") ||
    lower.endsWith(".webp")
  ) {
    return ImageIcon;
  }

  return FileText;
}

export default function AiPlannerPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();
  const supabase = useMemo(() => createClient(), []);

  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedTasks, setGeneratedTasks] = useState<GeneratedTask[]>([]);
  const [error, setError] = useState("");
  const [projects, setProjects] = useState<ProjectOption[]>([]);
 const [selectedProjectId, setSelectedProjectId] = useState(
  () => searchParams.get("projectId") ?? ""
);
  const [savingTasks, setSavingTasks] = useState(false);
  const [saveMessage, setSaveMessage] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedSavedDocument, setSelectedSavedDocument] =
    useState<SavedProjectDocument | null>(null);
  const [lastGenerationMode, setLastGenerationMode] = useState<
    "prompt" | "file" | "savedDocument" | null
  >(null);

  const canGenerateFromPrompt = useMemo(
    () => prompt.trim().length > 10,
    [prompt]
  );

  const canGenerateFromFile = Boolean(selectedFile);
  const canGenerateFromSavedDocument = Boolean(selectedSavedDocument);

  useEffect(() => {
    async function loadProjects() {
      const { data, error } = await supabase
        .from("projects")
        .select("id, name")
        .order("created_at", { ascending: false });

      if (error) {
        setError(error.message);
        return;
      }

      setProjects((data ?? []) as ProjectOption[]);
    }

    void loadProjects();
  }, []);

  useEffect(() => {
  const documentIdFromQuery = searchParams.get("documentId");

  let cancelled = false;

  async function loadSavedDocument() {
    if (!documentIdFromQuery) {
      await Promise.resolve();

      if (!cancelled) {
        setSelectedSavedDocument(null);
      }
      return;
    }

    const { data, error } = await supabase
      .from("project_documents")
      .select("*")
      .eq("id", documentIdFromQuery)
      .single();

    if (cancelled) return;

    if (error) {
      setError(error.message);
      return;
    }

    const document = data as SavedProjectDocument;

    setSelectedSavedDocument(document);
    setSelectedFile(null);
    setPrompt("");
    setSelectedProjectId(document.project_id);
  }

  void loadSavedDocument();

  return () => {
    cancelled = true;
  };
}, [searchParams]);

  function resetMessages() {
    setError("");
    setSaveMessage("");
  }

  function updateUrlAfterClearingSavedDocument() {
    const params = new URLSearchParams(searchParams.toString());
    params.delete("documentId");

    const query = params.toString();
    router.replace(query ? `${pathname}?${query}` : pathname);
  }

  function clearSavedDocumentSelection() {
    setSelectedSavedDocument(null);
    updateUrlAfterClearingSavedDocument();
  }

  function handleExampleClick(value: string) {
    clearSavedDocumentSelection();
    setSelectedFile(null);
    setPrompt(value);
    resetMessages();
  }

  function handleFileChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0] ?? null;

    setSelectedFile(file);
    resetMessages();

    if (file) {
      clearSavedDocumentSelection();
      setPrompt("");
    }
  }

  function handleRemoveFile() {
    setSelectedFile(null);
    resetMessages();
  }

  async function handleGenerate() {
    if (!canGenerateFromPrompt) return;

    setIsGenerating(true);
    setGeneratedTasks([]);
    resetMessages();

    try {
      const response = await fetch("/api/ai/generate-tasks", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ prompt }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to generate tasks.");
      }

      setGeneratedTasks(normalizeTasks(data.tasks));
      setLastGenerationMode("prompt");
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong while generating tasks."
      );
    } finally {
      setIsGenerating(false);
    }
  }

  async function handleGenerateFromFile() {
    if (!selectedFile) return;

    setIsGenerating(true);
    setGeneratedTasks([]);
    resetMessages();

    try {
      const formData = new FormData();
      formData.append("file", selectedFile);

      const response = await fetch("/api/ai/generate-tasks-from-file", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to generate tasks from file.");
      }

      setGeneratedTasks(normalizeTasks(data.tasks));
      setLastGenerationMode("file");
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong while generating tasks from the uploaded file."
      );
    } finally {
      setIsGenerating(false);
    }
  }

  async function handleGenerateFromSavedDocument() {
    if (!selectedSavedDocument) return;

    setIsGenerating(true);
    setGeneratedTasks([]);
    resetMessages();

    try {
      const response = await fetch(
        "/api/ai/generate-tasks-from-saved-document",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            publicUrl: selectedSavedDocument.public_url,
            fileName: selectedSavedDocument.file_name,
            mimeType: selectedSavedDocument.mime_type,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Failed to generate tasks from saved document."
        );
      }

      setGeneratedTasks(normalizeTasks(data.tasks));
      setLastGenerationMode("savedDocument");
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong while generating tasks from the saved document."
      );
    } finally {
      setIsGenerating(false);
    }
  }

  async function handleRetryGeneration() {
    if (lastGenerationMode === "savedDocument" && selectedSavedDocument) {
      await handleGenerateFromSavedDocument();
      return;
    }

    if (lastGenerationMode === "file" && selectedFile) {
      await handleGenerateFromFile();
      return;
    }

    if (lastGenerationMode === "prompt" && canGenerateFromPrompt) {
      await handleGenerate();
    }
  }

  async function handleSaveTasks() {
    if (!selectedProjectId) {
      setSaveMessage("Please select a project first.");
      return;
    }

    if (generatedTasks.length === 0) {
      setSaveMessage("Generate tasks before saving.");
      return;
    }

    setSavingTasks(true);
    setSaveMessage("");
    setError("");

    const tasksToInsert = generatedTasks.map((task) => ({
      project_id: selectedProjectId,
      title: task.title,
      description: task.description,
      priority: task.priority,
      status: task.status,
      acceptance_criteria: task.acceptanceCriteria,
    }));

    const { error } = await supabase.from("tasks").insert(tasksToInsert);

    if (error) {
      setSaveMessage(error.message);
      setSavingTasks(false);
      return;
    }

    setSaveMessage("Tasks saved successfully.");
    setSavingTasks(false);
  }

  return (
    <div className="space-y-8">
      <motion.section
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="grid gap-6 xl:grid-cols-[1.4fr_0.9fr]"
      >
        <div className="rounded-[28px] border border-white/10 bg-white/5 p-6 md:p-8">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-sm text-white/60">
            <Sparkles className="h-4 w-4" />
            AI Task Generator
          </div>

          <h1 className="text-3xl font-semibold md:text-4xl">
            Turn ideas or project files into sprint-ready tasks
          </h1>

          <p className="mt-4 max-w-2xl text-sm leading-6 text-white/60 md:text-base">
            Write a feature idea, upload a file, or use a saved project document.
            SprintFlow AI will turn it into structured tasks with priorities,
            statuses, and acceptance criteria.
          </p>

          {selectedSavedDocument && (
            <div className="mt-6 rounded-3xl border border-white/10 bg-black/30 p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  {(() => {
                    const FileIcon = getFileIcon(selectedSavedDocument.file_name);
                    return (
                      <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
                        <FileIcon className="h-5 w-5 text-white/80" />
                      </div>
                    );
                  })()}

                  <div>
                    <p className="text-sm font-medium text-white">
                      {selectedSavedDocument.file_name}
                    </p>
                    <p className="mt-1 text-xs text-white/45">
                      Using a saved project document
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={clearSavedDocumentSelection}
                  className="rounded-full border border-white/10 bg-white/5 p-2 text-white/70 transition hover:bg-white/10 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}

          <div className="mt-6">
            <label className="mb-3 block text-sm font-medium text-white/80">
              Describe your feature or goal
            </label>

            <Textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Example: Build a project management dashboard with login, team roles, task tracking, and progress analytics."
              className="min-h-[180px] resize-none rounded-3xl border-white/10 bg-black/30 text-white placeholder:text-white/30 focus-visible:ring-0 focus-visible:ring-offset-0"
              disabled={Boolean(selectedFile) || Boolean(selectedSavedDocument)}
            />

            <p className="mt-2 text-xs text-white/40">
              Prompt generation works best for short feature ideas. File upload
              works best for full requirement documents or screenshots.
            </p>
          </div>

          <div className="mt-6 rounded-3xl border border-white/10 bg-black/30 p-4">
            <div className="mb-3 flex items-center gap-2 text-sm font-medium text-white/80">
              <Paperclip className="h-4 w-4" />
              Upload project file
            </div>

            {!selectedFile ? (
              <label className="flex cursor-pointer flex-col items-center justify-center rounded-3xl border border-dashed border-white/15 bg-white/[0.03] px-6 py-8 text-center transition hover:bg-white/[0.06]">
                <Upload className="mb-3 h-6 w-6 text-white/70" />
                <span className="text-sm font-medium text-white">
                  Choose a file
                </span>
                <span className="mt-2 text-xs text-white/45">
                  Supported: {supportedFileTypes.join(", ")}
                </span>
                <input
                  type="file"
                  accept=".pdf,.docx,.png,.jpg,.jpeg,.webp"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </label>
            ) : (
              <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    {(() => {
                      const FileIcon = getFileIcon(selectedFile.name);
                      return (
                        <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
                          <FileIcon className="h-5 w-5 text-white/80" />
                        </div>
                      );
                    })()}

                    <div>
                      <p className="text-sm font-medium text-white">
                        {selectedFile.name}
                      </p>
                      <p className="mt-1 text-xs text-white/45">
                        {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleRemoveFile}
                    className="rounded-full border border-white/10 bg-white/5 p-2 text-white/70 transition hover:bg-white/10 hover:text-white"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>

                <p className="mt-3 text-xs text-white/45">
                  Prompt input is disabled while a file is attached. Remove the
                  file to switch back to text-based generation.
                </p>
              </div>
            )}
          </div>

          <div className="mt-5">
            <label className="mb-3 block text-sm font-medium text-white/80">
              Select project
            </label>

            <select
              value={selectedProjectId}
              onChange={(e) => setSelectedProjectId(e.target.value)}
              className="w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-white outline-none"
            >
              <option value="">Choose a project</option>
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </select>
          </div>

          <div className="mt-5 flex flex-wrap gap-3">
            <Button
              onClick={handleGenerate}
              disabled={
                !canGenerateFromPrompt ||
                isGenerating ||
                !!selectedFile ||
                !!selectedSavedDocument
              }
              className="rounded-2xl bg-white px-5 text-black hover:bg-white/90"
            >
              {isGenerating && lastGenerationMode === "prompt" ? (
                <>
                  <LoaderCircle className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <WandSparkles className="mr-2 h-4 w-4" />
                  Generate from Prompt
                </>
              )}
            </Button>

            <Button
              onClick={handleGenerateFromFile}
              disabled={
                !canGenerateFromFile || isGenerating || !!selectedSavedDocument
              }
              className="rounded-2xl bg-white/10 px-5 text-white hover:bg-white/20"
            >
              {isGenerating && lastGenerationMode === "file" ? (
                <>
                  <LoaderCircle className="mr-2 h-4 w-4 animate-spin" />
                  Reading File...
                </>
              ) : (
                <>
                  <Paperclip className="mr-2 h-4 w-4" />
                  Generate from File
                </>
              )}
            </Button>

            <Button
              onClick={handleGenerateFromSavedDocument}
              disabled={!canGenerateFromSavedDocument || isGenerating}
              className="rounded-2xl bg-white/10 px-5 text-white hover:bg-white/20"
            >
              {isGenerating && lastGenerationMode === "savedDocument" ? (
                <>
                  <LoaderCircle className="mr-2 h-4 w-4 animate-spin" />
                  Reading Saved Doc...
                </>
              ) : (
                <>
                  <Paperclip className="mr-2 h-4 w-4" />
                  Generate from Saved Doc
                </>
              )}
            </Button>

            <Button
              variant="outline"
              onClick={() => {
                setPrompt("");
                setSelectedFile(null);
                clearSavedDocumentSelection();
                setGeneratedTasks([]);
                setError("");
                setSaveMessage("");
                setLastGenerationMode(null);
              }}
              className="rounded-2xl border-white/10 bg-white/5 text-white hover:bg-white/10 hover:text-white"
            >
              Clear
            </Button>

            <Button
              onClick={handleSaveTasks}
              disabled={savingTasks || generatedTasks.length === 0}
              className="rounded-2xl bg-white/10 px-5 text-white hover:bg-white/20"
            >
              {savingTasks ? "Saving..." : "Save All Tasks"}
            </Button>

            <Button
              onClick={handleRetryGeneration}
              disabled={
                isGenerating ||
                (!canGenerateFromPrompt &&
                  !canGenerateFromFile &&
                  !canGenerateFromSavedDocument)
              }
              className="rounded-2xl bg-white/5 px-5 text-white hover:bg-white/10"
            >
              Retry
            </Button>
          </div>

          {error && (
            <div className="mt-4 rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
              {error}
            </div>
          )}

          {saveMessage && (
            <div className="mt-4 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/80">
              {saveMessage}
            </div>
          )}
        </div>

        <div className="rounded-[28px] border border-white/10 bg-white/5 p-6 md:p-8">
          <p className="text-sm text-white/50">Quick examples</p>
          <h2 className="mt-2 text-xl font-semibold">Try one of these prompts</h2>

          <div className="mt-5 space-y-3">
            {examplePrompts.map((example, index) => (
              <motion.button
                key={example}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.25, delay: index * 0.08 }}
                onClick={() => handleExampleClick(example)}
                className="w-full rounded-3xl border border-white/10 bg-black/30 p-4 text-left transition hover:bg-white/5"
                disabled={Boolean(selectedFile) || Boolean(selectedSavedDocument)}
              >
                <p className="text-sm leading-6 text-white/70">{example}</p>
              </motion.button>
            ))}
          </div>

          <div className="mt-6 rounded-3xl border border-dashed border-white/15 bg-black/30 p-5">
            <p className="text-sm text-white/50">What this will generate</p>

            <div className="mt-4 space-y-3 text-sm text-white/70">
              <div className="flex items-center gap-3">
                <ListTodo className="h-4 w-4" />
                Structured task breakdown
              </div>
              <div className="flex items-center gap-3">
                <Flag className="h-4 w-4" />
                Priority suggestions
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle2 className="h-4 w-4" />
                Acceptance criteria
              </div>
              <div className="flex items-center gap-3">
                <FileText className="h-4 w-4" />
                Requirement extraction from docs
              </div>
            </div>
          </div>

          <div className="mt-6 rounded-3xl border border-white/10 bg-black/30 p-5">
            <p className="text-sm text-white/50">Supported uploads</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {supportedFileTypes.map((type) => (
                <span
                  key={type}
                  className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/70"
                >
                  {type}
                </span>
              ))}
            </div>
          </div>
        </div>
      </motion.section>

      <section>
        <div className="mb-5">
          <p className="text-sm text-white/50">Generated Output</p>
          <h2 className="text-2xl font-semibold">AI Task Suggestions</h2>
        </div>

        <AnimatePresence mode="wait">
          {isGenerating ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid gap-5 md:grid-cols-2 xl:grid-cols-3"
            >
              {Array.from({ length: 3 }).map((_, index) => (
                <div
                  key={index}
                  className="rounded-[26px] border border-white/10 bg-white/5 p-5"
                >
                  <div className="mb-4 h-5 w-32 rounded-full bg-white/10" />
                  <div className="mb-3 h-4 w-full rounded-full bg-white/10" />
                  <div className="mb-3 h-4 w-5/6 rounded-full bg-white/10" />
                  <div className="mt-6 h-8 w-20 rounded-full bg-white/10" />
                </div>
              ))}
            </motion.div>
          ) : generatedTasks.length > 0 ? (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
              className="grid gap-5 md:grid-cols-2 xl:grid-cols-3"
            >
              {generatedTasks.map((task, index) => (
                <motion.div
                  key={`${task.id}-${index}`}
                  initial={{ opacity: 0, y: 18 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25, delay: index * 0.06 }}
                  whileHover={{ y: -5 }}
                  className="rounded-[26px] border border-white/10 bg-white/5 p-5 transition hover:bg-white/[0.07]"
                >
                  <div className="flex items-start justify-between gap-3">
                    <Badge className={getPriorityStyles(task.priority)}>
                      {task.priority}
                    </Badge>

                    <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/60">
                      {task.status}
                    </span>
                  </div>

                  <h3 className="mt-4 text-lg font-semibold text-white">
                    {task.title}
                  </h3>

                  <p className="mt-3 text-sm leading-6 text-white/60">
                    {task.description}
                  </p>

                  <div className="mt-5">
                    <p className="text-xs font-medium uppercase tracking-wide text-white/40">
                      Acceptance Criteria
                    </p>

                    <ul className="mt-3 space-y-2">
                      {task.acceptanceCriteria.map((item, itemIndex) => (
                        <li
                          key={`${task.id}-${itemIndex}`}
                          className="flex items-start gap-2 text-sm text-white/70"
                        >
                          <span className="mt-1 h-1.5 w-1.5 rounded-full bg-white/60" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="rounded-[28px] border border-dashed border-white/15 bg-white/5 p-10 text-center"
            >
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-3xl border border-white/10 bg-white/5">
                <Sparkles className="h-6 w-6 text-white/70" />
              </div>

              <h3 className="mt-5 text-xl font-semibold text-white">
                No tasks generated yet
              </h3>

              <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-white/60">
                Enter a feature idea, upload a project file, or use a saved
                project document to generate your first AI task plan.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </section>
    </div>
  );
}