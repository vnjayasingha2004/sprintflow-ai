"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function TestSupabasePage() {
  const [message, setMessage] = useState("Not tested yet");

  async function testConnection() {
    try {
      const { error } = await supabase.from("projects").select("*").limit(1);

      if (error) {
        setMessage(`Connected, but got DB message: ${error.message}`);
        return;
      }

      setMessage("Supabase connected successfully.");
    } catch {
      setMessage("Something went wrong while testing Supabase.");
    }
  }

  return (
    <main className="min-h-screen bg-black px-6 py-10 text-white">
      <h1 className="text-3xl font-semibold">Test Supabase</h1>
      <button
        onClick={testConnection}
        className="mt-6 rounded-2xl bg-white px-5 py-3 font-medium text-black"
      >
        Test Connection
      </button>
      <p className="mt-4 text-white/70">{message}</p>
    </main>
  );
}