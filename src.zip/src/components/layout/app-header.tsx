"use client";

import { Bell, Search } from "lucide-react";
import { usePathname } from "next/navigation";

function getPageTitle(pathname: string) {
  if (pathname.startsWith("/projects")) return "Projects";
  if (pathname.startsWith("/ai-planner")) return "AI Planner";
  if (pathname.startsWith("/settings")) return "Settings";
  return "Dashboard Overview";
}

export function AppHeader() {
  const pathname = usePathname();
  const title = getPageTitle(pathname);

  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-black/80 backdrop-blur-xl">
      <div className="flex items-center justify-between gap-4 px-6 py-4 md:px-8">
        <div>
          <p className="text-sm text-white/50">Welcome back</p>
          <h1 className="text-xl font-semibold text-white">{title}</h1>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/50 md:flex">
            <Search className="h-4 w-4" />
            <span>Search projects or tasks</span>
          </div>

          <button className="rounded-2xl border border-white/10 bg-white/5 p-3 text-white/70 transition hover:bg-white/10 hover:text-white">
            <Bell className="h-5 w-5" />
          </button>

          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white text-sm font-semibold text-black">
            VJ
          </div>
        </div>
      </div>
    </header>
  );
}